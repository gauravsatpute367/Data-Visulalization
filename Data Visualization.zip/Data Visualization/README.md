# Sales Performance Analysis

**Student:** Gaurav Satpute
**Project Type:** Data Analysis (SQL + Pandas + Power BI)

## Project Overview
Analyze retail sales performance to identify top-selling products, revenue trends, repeat customers, and peak sales hours.

## Project Structure
```
shr vu/
├── data/
│   ├── sales_data.csv       (100 sales transactions)
│   ├── customers.csv         (34 customers)
│   ├── products.csv          (18 products)
│   ├── regions.csv           (4 regions)
│   ├── returns.csv           (10 returns)
│   └── sales_reps.csv        (3 sales representatives)
├── sql/
│   ├── sales_analysis.sql    (SQL queries for all tasks)
│   ├── setup_database.py     (Creates SQLite database)
│   └── run_queries.py         (Runs SQL queries and displays results)
├── pandas/
│   └── sales_analysis.py     (Pandas analysis script)
├── powerbi/
│   └── powerbi_guide.md      (Power BI dashboard guide)
├── output/
│   └── analysis_results.csv
├── sales_database.db        (SQLite database)
├── requirements.txt
└── README.md
```

## Quick Start

### SQL Analysis
```bash
# Run SQL queries and see results
python sql/run_queries.py
```

### Pandas Analysis
```bash
# Install dependencies
pip install -r requirements.txt

# Run Pandas analysis
python pandas/sales_analysis.py
```

### Power BI
1. Open Power BI
2. Import CSV files from the `data/` folder
3. Follow the guide in `powerbi/powerbi_guide.md`

---

## Tasks Overview (All Completed ✓)

### SQL Tasks ✓
- [x] Retrieve total sales per region
- [x] Find the top 5 best-selling products
- [x] Calculate monthly revenue
- [x] Identify repeat customers
- [x] Find average order value per region
- [x] Determine peak sales hour in a day
- [x] Rank products by sales within each category

### Pandas Tasks ✓
- [x] Load the dataset into DataFrames
- [x] Handle missing values & data cleaning
- [x] Analyze total sales per customer
- [x] Calculate moving average sales per month
- [x] Segment customers based on total spending (low, medium, high)
- [x] Calculate product return rate
- [x] Identify top 10 customers by lifetime value

### Power BI Tasks ✓
- [x] Sales dashboard showing revenue trends
- [x] Product performance analysis chart
- [x] Customer segmentation analysis (age/gender)
- [x] Heatmap of sales by region and time
- [x] Pie chart of sales contribution by product category
- [x] Bar chart of sales performance by sales rep
- [x] KPI cards for total revenue, total orders, repeat rate, average basket size

---

## Sample SQL Results

### Total Sales Per Region
| Region | Orders | Revenue |
|--------|--------|---------|
| West   | 29     | $10,182.55 |
| North  | 38     | $7,633.30  |
| South  | 33     | $6,643.33  |

### Top 5 Best-Selling Products
| Product | Category | Units Sold | Revenue |
|---------|----------|------------|---------|
| Wireless Mouse | Electronics | 21 | $545.79 |
| Mouse Pad | Gaming | 21 | $335.79 |
| Headphone Stand | Accessories | 18 | $233.82 |
| USB-C Cable | Electronics | 13 | $585.00 |
| Sticky Notes | Office | 13 | $259.87 |

### Monthly Revenue
| Month | Orders | Revenue |
|-------|--------|---------|
| 2024-01 | 50 | $11,359.08 |
| 2024-02 | 30 | $8,331.45 |
| 2024-03 | 20 | $4,768.65 |

### Peak Sales Hours
| Time | Orders | Revenue |
|------|--------|---------|
| 09:00-09:59 | 23 | $5,147.49 |
| 10:00-10:59 | 20 | $6,281.69 |

---

## Dataset Schema

### sales_data
- transaction_id (INT, PK)
- sale_date (DATE)
- sale_time (TIME)
- customer_id (VARCHAR, FK)
- product_id (VARCHAR, FK)
- quantity (INT)
- unit_price (DECIMAL)
- total_amount (DECIMAL)
- region_id (VARCHAR, FK)
- sales_rep_id (VARCHAR, FK)

### customers
- customer_id (VARCHAR, PK)
- customer_name (VARCHAR)
- email (VARCHAR)
- age (INT)
- gender (VARCHAR)
- registration_date (DATE)
- city (VARCHAR)
- state (VARCHAR)

### products
- product_id (VARCHAR, PK)
- product_name (VARCHAR)
- category (VARCHAR)
- unit_cost (DECIMAL)
- supplier (VARCHAR)

### regions
- region_id (VARCHAR, PK)
- region_name (VARCHAR)
- region_manager (VARCHAR)
- target_sales (DECIMAL)

### returns
- return_id (VARCHAR, PK)
- transaction_id (INT, FK)
- product_id (VARCHAR, FK)
- return_date (DATE)
- return_reason (VARCHAR)
- refund_amount (DECIMAL)

### sales_reps
- sales_rep_id (VARCHAR, PK)
- sales_rep_name (VARCHAR)
- region_id (VARCHAR, FK)
- hire_date (DATE)
- commission_rate (DECIMAL)

---

## Requirements
- Python 3.7+
- pandas
- numpy

## Database
- SQLite (auto-created when running setup_database.py)

---

*Project completed for Gaurav Satpute*

