# Power BI Dashboard Guide
## Student: Gaurav Satpute

This guide provides instructions for creating the Power BI visualizations for the Sales Performance Analysis project.

## Data Files to Import
Import the following CSV files into Power BI:
- `data/sales_data.csv`
- `data/customers.csv`
- `data/products.csv`
- `data/regions.csv`
- `data/returns.csv`
- `data/sales_reps.csv`

## Data Model Relationships
Create the following relationships in Power BI:
1. `sales_data.customer_id` → `customers.customer_id`
2. `sales_data.product_id` → `products.product_id`
3. `sales_data.region_id` → `regions.region_id`
4. `sales_data.sales_rep_id` → `sales_reps.sales_rep_id`
5. `sales_data.transaction_id` → `returns.transaction_id`

---

## Dashboard Components

### 1. KPI Cards (4 cards)
Create 4 card visualizations with the following measures:

| KPI | DAX Measure |
|-----|-------------|
| Total Revenue | `SUM(sales_data[total_amount])` |
| Total Orders | `COUNT(sales_data[transaction_id])` |
| Repeat Rate | `DIVIDE(COUNTROWS(VALUES(sales_data[customer_id])) - DISTINCTCOUNT(sales_data[customer_id]), COUNTROWS(VALUES(sales_data[customer_id]))` * 100 |
| Average Basket Size | `AVERAGE(sales_data[total_amount])` |

### 2. Sales Dashboard - Revenue Trends
**Visual:** Line Chart
- X-axis: `sales_data[sale_date]` (by Month)
- Y-axis: `SUM(sales_data[total_amount])`
- Title: "Monthly Revenue Trend"

### 3. Product Performance Analysis Chart
**Visual:** Bar Chart (Horizontal)
- Y-axis: `products[product_name]`
- X-axis: `SUM(sales_data[total_amount])`
- Color: `products[category]`
- Title: "Top Products by Revenue"

### 4. Customer Segmentation Analysis
**Visual:** Clustered Bar Chart or Stacked Bar
- X-axis: `customers[gender]`
- Y-axis: `SUM(sales_data[total_amount])`
- Cluster: Age groups (create age bins in Power Query)
- Title: "Sales by Customer Age and Gender"

### 5. Heatmap of Sales by Region and Time
**Visual:** Matrix Table or Heatmap
- Rows: `regions[region_name]`
- Columns: Month (from `sales_data[sale_date]`)
- Values: `SUM(sales_data[total_amount])`
- Conditional formatting: Color scale
- Title: "Sales Heatmap by Region and Month"

### 6. Pie Chart - Sales by Product Category
**Visual:** Donut Chart
- Legend: `products[category]`
- Values: `SUM(sales_data[total_amount])`
- Title: "Sales Contribution by Category"

### 7. Bar Chart - Sales Performance by Sales Rep
**Visual:** Bar Chart
- X-axis: `sales_reps[sales_rep_name]`
- Y-axis: `SUM(sales_data[total_amount])`
- Color: `regions[region_name]`
- Title: "Sales Performance by Sales Rep"

---

## DAX Measures to Create

```DAX
// Total Revenue
Total Revenue = SUM(sales_data[total_amount])

// Total Orders
Total Orders = COUNT(sales_data[transaction_id])

// Unique Customers
Unique Customers = DISTINCTCOUNT(sales_data[customer_id])

// Repeat Customers
Repeat Customers = 
CALCULATE(
    DISTINCTCOUNT(sales_data[customer_id]),
    FILTER(
        sales_data,
        CALCULATE(COUNT(sales_data[transaction_id]), ALLEXCEPT(sales_data, sales_data[customer_id])) > 1
    )
)

// Repeat Rate
Repeat Rate = 
DIVIDE([Repeat Customers], [Unique Customers], 0) * 100

// Average Order Value
Average Order Value = AVERAGE(sales_data[total_amount])

// Month Name
Month Name = FORMAT(sales_data[sale_date], "MMMM YYYY")

// Hour of Day
Hour of Day = HOUR(sales_data[sale_time])

// Customer Age Group
Age Group = 
SWITCH(
    TRUE,
    customers[age] < 25, "18-24",
    customers[age] < 35, "25-34",
    customers[age] < 45, "35-44",
    customers[age] < 55, "45-54",
    "55+"
)
```

---

## Dashboard Layout Recommendation

```
+------------------------------------------+
|  [KPI1]  [KPI2]  [KPI3]  [KPI4]         |
|  Revenue Orders Repeat Avg Basket       |
+------------------------------------------+
|                                          |
|   [Revenue Trend - Line Chart]          |
|                                          |
+------------------------------------------+
|                    |                     |
|   [Product         |  [Sales by         |
|    Performance]    |   Category]         |
|                    |                     |
+--------------------+---------------------+
|                    |                     |
|   [Customer        |  [Sales by         |
|    Segmentation]  |   Region/Time]     |
|                    |                     |
+--------------------+---------------------+
|                                          |
|   [Sales Rep Performance]               |
|                                          |
+------------------------------------------+
```

---

## Color Palette
Use professional colors for the dashboard:
- Primary: #1F77B4 (Blue)
- Secondary: #FF7F0E (Orange)
- Accent: #2CA02C (Green)
- Background: #F0F0F0 (Light Gray)
- Text: #333333 (Dark Gray)

---

## Export Instructions
1. Go to File → Export → Export to PowerPoint (or PDF)
2. Or use Publish to Power BI Service for online sharing

---

*Created for Gaurav Satpute - Sales Performance Analysis Project*

