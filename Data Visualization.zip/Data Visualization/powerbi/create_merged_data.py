# ============================================================================
# Power BI Data Preparation Script
# Creates merged datasets for easier Power BI import
# ============================================================================

import pandas as pd
import sqlite3
import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
db_path = os.path.join(base_dir, 'sales_database.db')
output_dir = os.path.join(base_dir, 'powerbi')

# Connect to database
conn = sqlite3.connect(db_path)

print("Creating Power BI-ready datasets...")

# Load base data
sales_df = pd.read_sql("SELECT * FROM sales_data", conn)
customers_df = pd.read_sql("SELECT * FROM customers", conn)
products_df = pd.read_sql("SELECT * FROM products", conn)
regions_df = pd.read_sql("SELECT * FROM regions", conn)
returns_df = pd.read_sql("SELECT * FROM returns", conn)
sales_reps_df = pd.read_sql("SELECT * FROM sales_reps", conn)

# Create merged sales dataset for Power BI
# Step by step to avoid duplicate column issues
merged_sales = sales_df.merge(customers_df, on='customer_id', how='left')
merged_sales = merged_sales.merge(products_df, on='product_id', how='left', suffixes=('', '_prod'))

# Get region name separately
region_map = regions_df[['region_id', 'region_name']].copy()
merged_sales = merged_sales.merge(region_map, on='region_id', how='left')

# Get sales rep info
sales_rep_map = sales_reps_df[['sales_rep_id', 'sales_rep_name']].copy()
merged_sales = merged_sales.merge(sales_rep_map, on='sales_rep_id', how='left')

# Add return information
returns_info = returns_df[['transaction_id', 'return_id', 'return_date', 'return_reason', 'refund_amount']].copy()
merged_sales = merged_sales.merge(returns_info, on='transaction_id', how='left')

# Add calculated columns
merged_sales['is_returned'] = merged_sales['return_id'].notna()
merged_sales['month'] = pd.to_datetime(merged_sales['sale_date']).dt.strftime('%Y-%m')
merged_sales['month_name'] = pd.to_datetime(merged_sales['sale_date']).dt.strftime('%B %Y')
merged_sales['hour'] = pd.to_datetime(merged_sales['sale_time'], format='%H:%M:%S').dt.hour
merged_sales['day_of_week'] = pd.to_datetime(merged_sales['sale_date']).dt.day_name()

# Add customer age group
def get_age_group(age):
    if pd.isna(age):
        return 'Unknown'
    if age < 25:
        return '18-24'
    elif age < 35:
        return '25-34'
    elif age < 45:
        return '35-44'
    elif age < 55:
        return '45-54'
    else:
        return '55+'

merged_sales['age_group'] = merged_sales['age'].apply(get_age_group)

# Save merged dataset
output_file = os.path.join(output_dir, 'merged_sales_data.csv')
merged_sales.to_csv(output_file, index=False)
print(f"Created: {output_file}")

# Create summary tables for Power BI

# 1. Monthly Summary
monthly_summary = merged_sales.groupby('month').agg({
    'transaction_id': 'count',
    'total_amount': 'sum',
    'quantity': 'sum',
    'customer_id': 'nunique'
}).reset_index()
monthly_summary.columns = ['month', 'order_count', 'revenue', 'units_sold', 'unique_customers']
monthly_summary.to_csv(os.path.join(output_dir, 'monthly_summary.csv'), index=False)
print(f"Created: {output_dir}/monthly_summary.csv")

# 2. Region Summary
region_summary = merged_sales.groupby(['region_id', 'region_name']).agg({
    'transaction_id': 'count',
    'total_amount': 'sum',
    'quantity': 'sum',
    'customer_id': 'nunique'
}).reset_index()
region_summary.columns = ['region_id', 'region_name', 'order_count', 'revenue', 'units_sold', 'unique_customers']
region_summary.to_csv(os.path.join(output_dir, 'region_summary.csv'), index=False)
print(f"Created: {output_dir}/region_summary.csv")

# 3. Product Category Summary
category_summary = merged_sales.groupby('category').agg({
    'transaction_id': 'count',
    'total_amount': 'sum',
    'quantity': 'sum'
}).reset_index()
category_summary.columns = ['category', 'order_count', 'revenue', 'units_sold']
category_summary.to_csv(os.path.join(output_dir, 'category_summary.csv'), index=False)
print(f"Created: {output_dir}/category_summary.csv")

# 4. Customer Summary with segments
customer_spending = merged_sales.groupby('customer_id').agg({
    'transaction_id': 'count',
    'total_amount': 'sum',
    'quantity': 'sum'
}).reset_index()
customer_spending.columns = ['customer_id', 'order_count', 'lifetime_value', 'total_items']

customer_spending = customer_spending.merge(customers_df[['customer_id', 'customer_name', 'age', 'gender', 'state']], on='customer_id')

# Add segment
def get_spending_segment(amount):
    if amount < 200:
        return 'Low'
    elif amount < 500:
        return 'Medium'
    else:
        return 'High'

customer_spending['spending_segment'] = customer_spending['lifetime_value'].apply(get_spending_segment)
customer_spending['age_group'] = customer_spending['age'].apply(get_age_group)
customer_spending.to_csv(os.path.join(output_dir, 'customer_summary.csv'), index=False)
print(f"Created: {output_dir}/customer_summary.csv")

# 5. Sales Rep Performance
rep_summary = merged_sales.groupby(['sales_rep_id', 'sales_rep_name', 'region_name']).agg({
    'transaction_id': 'count',
    'total_amount': 'sum',
    'quantity': 'sum'
}).reset_index()
rep_summary.columns = ['sales_rep_id', 'sales_rep_name', 'region', 'order_count', 'revenue', 'units_sold']
rep_summary.to_csv(os.path.join(output_dir, 'sales_rep_summary.csv'), index=False)
print(f"Created: {output_dir}/sales_rep_summary.csv")

# 6. Hourly Analysis
hourly_summary = merged_sales.groupby('hour').agg({
    'transaction_id': 'count',
    'total_amount': 'sum'
}).reset_index()
hourly_summary.columns = ['hour', 'order_count', 'revenue']
hourly_summary.to_csv(os.path.join(output_dir, 'hourly_summary.csv'), index=False)
print(f"Created: {output_dir}/hourly_summary.csv")

conn.close()

print("\n" + "=" * 50)
print("Power BI data files created successfully!")
print("=" * 50)
print(f"\nFiles created in: {output_dir}")
print("- merged_sales_data.csv (main dataset)")
print("- monthly_summary.csv")
print("- region_summary.csv")
print("- category_summary.csv")
print("- customer_summary.csv")
print("- sales_rep_summary.csv")
print("- hourly_summary.csv")
print("\nImport these files into Power BI for easy dashboard creation!")

