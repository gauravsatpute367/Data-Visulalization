# ============================================================================
# SALES PERFORMANCE ANALYSIS - Pandas
# Student: Shravani Bhatkar
# ============================================================================

import pandas as pd
import numpy as np
from datetime import datetime

# ============================================================================
# TASK 1: Load the dataset into DataFrames
# ============================================================================
print("=" * 60)
print("TASK 1: Loading datasets into DataFrames")
print("=" * 60)

# Load all CSV files
sales_df = pd.read_csv('../data/sales_data.csv')
customers_df = pd.read_csv('../data/customers.csv')
products_df = pd.read_csv('../data/products.csv')
regions_df = pd.read_csv('../data/regions.csv')
returns_df = pd.read_csv('../data/returns.csv')
sales_reps_df = pd.read_csv('../data/sales_reps.csv')

print(f"Sales Data: {len(sales_df)} records")
print(f"Customers Data: {len(customers_df)} records")
print(f"Products Data: {len(products_df)} records")
print(f"Regions Data: {len(regions_df)} records")
print(f"Returns Data: {len(returns_df)} records")
print(f"Sales Reps Data: {len(sales_reps_df)} records")

# Convert date columns
sales_df['sale_date'] = pd.to_datetime(sales_df['sale_date'])
sales_df['sale_time'] = pd.to_datetime(sales_df['sale_time'], format='%H:%M:%S')

# ============================================================================
# TASK 2: Handle missing values & data cleaning
# ============================================================================
print("\n" + "=" * 60)
print("TASK 2: Handle missing values & data cleaning")
print("=" * 60)

# Check for missing values
print("\nMissing values in each dataset:")
print("Sales:", sales_df.isnull().sum().sum())
print("Customers:", customers_df.isnull().sum().sum())
print("Products:", products_df.isnull().sum().sum())

# Check for duplicates
print("\nDuplicate records:")
print("Sales:", sales_df.duplicated().sum())
print("Customers:", customers_df.duplicated().sum())

# Data cleaning - handle any issues
# Fill missing customer names if any
sales_df['customer_id'].fillna('UNKNOWN', inplace=True)

# Ensure numeric columns are correct type
sales_df['quantity'] = pd.to_numeric(sales_df['quantity'], errors='coerce')
sales_df['unit_price'] = pd.to_numeric(sales_df['unit_price'], errors='coerce')
sales_df['total_amount'] = pd.to_numeric(sales_df['total_amount'], errors='coerce')

# Remove any negative values (returns are handled separately)
sales_df = sales_df[sales_df['total_amount'] > 0]

print(f"\nCleaned sales data: {len(sales_df)} records")

# ============================================================================
# TASK 3: Analyze total sales per customer
# ============================================================================
print("\n" + "=" * 60)
print("TASK 3: Total sales per customer")
print("=" * 60)

customer_sales = sales_df.groupby('customer_id').agg({
    'transaction_id': 'count',
    'total_amount': ['sum', 'mean']
}).round(2)
customer_sales.columns = ['order_count', 'total_spent', 'avg_order_value']
customer_sales = customer_sales.sort_values('total_spent', ascending=False)

print("\nTop 10 customers by total spending:")
print(customer_sales.head(10))

# Merge with customer details
customer_details = customer_sales.merge(
    customers_df[['customer_id', 'customer_name', 'age', 'gender']], 
    on='customer_id'
)
print("\nCustomer details with spending:")
print(customer_details.head(10))

# ============================================================================
# TASK 4: Calculate moving average sales per month
# ============================================================================
print("\n" + "=" * 60)
print("TASK 4: Moving average sales per month")
print("=" * 60)

# Extract month from sale_date
sales_df['month'] = sales_df['sale_date'].dt.to_period('M')

# Calculate monthly revenue
monthly_revenue = sales_df.groupby('month')['total_amount'].sum().reset_index()
monthly_revenue.columns = ['month', 'revenue']

# Calculate 3-month moving average
monthly_revenue['moving_avg_3month'] = monthly_revenue['revenue'].rolling(window=3).mean().round(2)

print("\nMonthly revenue with 3-month moving average:")
print(monthly_revenue)

# ============================================================================
# TASK 5: Segment customers based on total spending (low, medium, high)
# ============================================================================
print("\n" + "=" * 60)
print("TASK 5: Customer segmentation by spending")
print("=" * 60)

# Calculate total spending per customer
total_spending = sales_df.groupby('customer_id')['total_amount'].sum().reset_index()
total_spending.columns = ['customer_id', 'total_spent']

# Define segments based on spending
def segment_customer(amount):
    if amount < 200:
        return 'Low'
    elif amount < 500:
        return 'Medium'
    else:
        return 'High'

total_spending['segment'] = total_spending['total_spent'].apply(segment_customer)

# Merge with customer details
customer_segments = total_spending.merge(
    customers_df[['customer_id', 'customer_name', 'age', 'gender']], 
    on='customer_id'
)

print("\nCustomer segmentation:")
print(total_spending.groupby('segment').agg({
    'customer_id': 'count',
    'total_spent': ['sum', 'mean', 'min', 'max']
}).round(2))

print("\nCustomer segment details:")
print(customer_segments.sort_values('total_spent', ascending=False))

# ============================================================================
# TASK 6: Calculate product return rate
# ============================================================================
print("\n" + "=" * 60)
print("TASK 6: Product return rate")
print("=" * 60)

# Count sales per product
product_sales = sales_df.groupby('product_id').agg({
    'transaction_id': 'count',
    'quantity': 'sum'
}).reset_index()
product_sales.columns = ['product_id', 'sales_count', 'quantity_sold']

# Count returns per product
product_returns = returns_df.groupby('product_id').size().reset_index(name='return_count')

# Merge and calculate return rate
product_performance = product_sales.merge(product_returns, on='product_id', how='left')
product_performance['return_count'] = product_performance['return_count'].fillna(0)
product_performance['return_rate'] = (
    product_performance['return_count'] / product_performance['sales_count'] * 100
).round(2)

# Merge with product names
product_performance = product_performance.merge(
    products_df[['product_id', 'product_name', 'category']], 
    on='product_id'
)

print("\nProduct return rates:")
print(product_performance.sort_values('return_rate', ascending=False))

# Overall return rate
total_sales = sales_df['transaction_id'].count()
total_returns = len(returns_df)
overall_return_rate = (total_returns / total_sales * 100)
print(f"\nOverall return rate: {overall_return_rate:.2f}%")

# ============================================================================
# TASK 7: Identify top 10 customers by lifetime value
# ============================================================================
print("\n" + "=" * 60)
print("TASK 7: Top 10 customers by lifetime value")
print("=" * 60)

# Calculate lifetime value per customer
lifetime_value = sales_df.groupby('customer_id').agg({
    'transaction_id': 'count',
    'total_amount': 'sum',
    'quantity': 'sum'
}).reset_index()
lifetime_value.columns = ['customer_id', 'total_orders', 'lifetime_value', 'total_items']

# Merge with customer details
top_customers = lifetime_value.merge(
    customers_df[['customer_id', 'customer_name', 'age', 'gender', 'state']], 
    on='customer_id'
)
top_customers = top_customers.sort_values('lifetime_value', ascending=False)

print("\nTop 10 customers by lifetime value:")
print(top_customers.head(10))

# Save results to CSV
top_customers.head(10).to_csv('../output/top_10_customers.csv', index=False)
print("\nSaved top 10 customers to ../output/top_10_customers.csv")

# ============================================================================
# ADDITIONAL ANALYSES
# ============================================================================
print("\n" + "=" * 60)
print("ADDITIONAL ANALYSES")
print("=" * 60)

# Sales by region
print("\nSales by region:")
region_sales = sales_df.groupby('region_id')['total_amount'].sum().reset_index()
region_sales = region_sales.merge(regions_df[['region_id', 'region_name']], on='region_id')
region_sales = region_sales.sort_values('total_amount', ascending=False)
print(region_sales)

# Peak sales hour
print("\nPeak sales hour:")
sales_df['hour'] = sales_df['sale_time'].dt.hour
hourly_sales = sales_df.groupby('hour')['total_amount'].agg(['count', 'sum']).reset_index()
hourly_sales.columns = ['hour', 'order_count', 'revenue']
hourly_sales = hourly_sales.sort_values('order_count', ascending=False)
print(hourly_sales)

# Sales by category
print("\nSales by product category:")
category_sales = sales_df.merge(products_df[['product_id', 'category']], on='product_id')
category_revenue = category_sales.groupby('category')['total_amount'].sum().reset_index()
category_revenue = category_revenue.sort_values('total_amount', ascending=False)
print(category_revenue)

# ============================================================================
# SUMMARY STATISTICS
# ============================================================================
print("\n" + "=" * 60)
print("SUMMARY STATISTICS")
print("=" * 60)

print(f"\nTotal Revenue: ${sales_df['total_amount'].sum():,.2f}")
print(f"Total Orders: {len(sales_df)}")
print(f"Average Order Value: ${sales_df['total_amount'].mean():,.2f}")
print(f"Unique Customers: {sales_df['customer_id'].nunique()}")
print(f"Unique Products Sold: {sales_df['product_id'].nunique()}")

# Repeat customers
repeat_customers = lifetime_value[lifetime_value['total_orders'] > 1]
repeat_rate = len(repeat_customers) / len(lifetime_value) * 100
print(f"Repeat Customer Rate: {repeat_rate:.2f}%")

print("\n" + "=" * 60)
print("Analysis Complete!")
print("=" * 60)

