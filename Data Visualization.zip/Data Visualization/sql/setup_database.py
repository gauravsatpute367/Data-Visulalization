# ============================================================================
# SQLite Database Setup Script
# Run this script to create and populate the SQLite database
# ============================================================================

import sqlite3
import pandas as pd
import os

# Get the base directory
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
data_dir = os.path.join(base_dir, 'data')
db_path = os.path.join(base_dir, 'sales_database.db')

print("Setting up SQLite database...")

# Create database connection
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Load CSV files
print("Loading CSV files...")
sales_df = pd.read_csv(os.path.join(data_dir, 'sales_data.csv'))
customers_df = pd.read_csv(os.path.join(data_dir, 'customers.csv'))
products_df = pd.read_csv(os.path.join(data_dir, 'products.csv'))
regions_df = pd.read_csv(os.path.join(data_dir, 'regions.csv'))
returns_df = pd.read_csv(os.path.join(data_dir, 'returns.csv'))
sales_reps_df = pd.read_csv(os.path.join(data_dir, 'sales_reps.csv'))

# Write to SQLite
print("Creating tables and inserting data...")

sales_df.to_sql('sales_data', conn, if_exists='replace', index=False)
customers_df.to_sql('customers', conn, if_exists='replace', index=False)
products_df.to_sql('products', conn, if_exists='replace', index=False)
regions_df.to_sql('regions', conn, if_exists='replace', index=False)
returns_df.to_sql('returns', conn, if_exists='replace', index=False)
sales_reps_df.to_sql('sales_reps', conn, if_exists='replace', index=False)

# Create indexes for better performance
cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales_data(customer_id)')
cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_product ON sales_data(product_id)')
cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_region ON sales_data(region_id)')
cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_date ON sales_data(sale_date)')

conn.commit()
conn.close()

print(f"\nDatabase created successfully: {db_path}")
print("\nTo run SQL queries, use:")
print(f"  sqlite3 {db_path}")
print("\nOr use a GUI tool like DBeaver, SQLite Studio, or VS Code SQLite extension.")
print("\nExample query to test:")
print("  sqlite3 sales_database.db 'SELECT region_name, SUM(total_amount) FROM sales_data s JOIN regions r ON s.region_id = r.region_id GROUP BY region_name;'")

