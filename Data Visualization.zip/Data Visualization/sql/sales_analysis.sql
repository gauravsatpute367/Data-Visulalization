-- ============================================================================
-- SALES PERFORMANCE ANALYSIS - SQL Queries
-- Student: Shravani Bhatkar
-- ============================================================================

-- ============================================================================
-- TASK 1: Retrieve total sales per region
-- ============================================================================
SELECT 
    r.region_name,
    COUNT(s.transaction_id) AS total_transactions,
    SUM(s.total_amount) AS total_sales
FROM sales_data s
JOIN regions r ON s.region_id = r.region_id
GROUP BY r.region_name
ORDER BY total_sales DESC;

-- ============================================================================
-- TASK 2: Find the top 5 best-selling products
-- ============================================================================
SELECT 
    p.product_name,
    p.category,
    SUM(s.quantity) AS total_quantity_sold,
    SUM(s.total_amount) AS total_revenue
FROM sales_data s
JOIN products p ON s.product_id = p.product_id
GROUP BY p.product_id, p.product_name, p.category
ORDER BY total_quantity_sold DESC
LIMIT 5;

-- ============================================================================
-- TASK 3: Calculate monthly revenue
-- ============================================================================
SELECT 
    strftime('%Y-%m', sale_date) AS month,
    COUNT(transaction_id) AS total_orders,
    SUM(total_amount) AS monthly_revenue
FROM sales_data
GROUP BY strftime('%Y-%m', sale_date)
ORDER BY month;

-- ============================================================================
-- TASK 4: Identify repeat customers
-- ============================================================================
-- Customers who made more than one purchase
SELECT 
    c.customer_id,
    c.customer_name,
    c.email,
    COUNT(s.transaction_id) AS purchase_count,
    SUM(s.total_amount) AS total_spent
FROM customers c
JOIN sales_data s ON c.customer_id = s.customer_id
GROUP BY c.customer_id, c.customer_name, c.email
HAVING COUNT(s.transaction_id) > 1
ORDER BY purchase_count DESC;

-- Total repeat customer count
SELECT 
    COUNT(DISTINCT customer_id) AS repeat_customer_count,
    (SELECT COUNT(DISTINCT customer_id) FROM sales_data) AS total_customers,
    ROUND(100.0 * COUNT(DISTINCT customer_id) / 
          (SELECT COUNT(DISTINCT customer_id) FROM sales_data), 2) AS repeat_rate_percentage
FROM sales_data
WHERE customer_id IN (
    SELECT customer_id 
    FROM sales_data 
    GROUP BY customer_id 
    HAVING COUNT(transaction_id) > 1
);

-- ============================================================================
-- TASK 5: Find average order value per region
-- ============================================================================
SELECT 
    r.region_name,
    COUNT(s.transaction_id) AS total_orders,
    ROUND(AVG(s.total_amount), 2) AS average_order_value,
    SUM(s.total_amount) AS total_revenue
FROM sales_data s
JOIN regions r ON s.region_id = r.region_id
GROUP BY r.region_name
ORDER BY average_order_value DESC;

-- ============================================================================
-- TASK 6: Determine peak sales hour in a day
-- ============================================================================
SELECT 
    CAST(strftime('%H', sale_time) AS INTEGER) AS hour_of_day,
    COUNT(transaction_id) AS number_of_orders,
    SUM(total_amount) AS hourly_revenue
FROM sales_data
GROUP BY hour_of_day
ORDER BY number_of_orders DESC;

-- Alternative: Show all hours in order
SELECT 
    CASE 
        WHEN CAST(strftime('%H', sale_time) AS INTEGER) = 0 THEN '12:00 AM'
        WHEN CAST(strftime('%H', sale_time) AS INTEGER) < 12 THEN 
            CAST(CAST(strftime('%H', sale_time) AS INTEGER) AS TEXT) || ':00 AM'
        WHEN CAST(strftime('%H', sale_time) AS INTEGER) = 12 THEN '12:00 PM'
        ELSE CAST(CAST(strftime('%H', sale_time) AS INTEGER) - 12 AS TEXT) || ':00 PM'
    END AS time_slot,
    COUNT(transaction_id) AS total_orders,
    SUM(total_amount) AS total_revenue
FROM sales_data
GROUP BY hour_of_day
ORDER BY hour_of_day;

-- ============================================================================
-- TASK 7: Rank products by sales within each category
-- ============================================================================
SELECT 
    p.category,
    p.product_name,
    SUM(s.total_amount) AS total_revenue,
    RANK() OVER (PARTITION BY p.category ORDER BY SUM(s.total_amount) DESC) AS category_rank,
    DENSE_RANK() OVER (ORDER BY SUM(s.total_amount) DESC) AS overall_rank
FROM sales_data s
JOIN products p ON s.product_id = p.product_id
GROUP BY p.category, p.product_id, p.product_name
ORDER BY p.category, category_rank;

-- ============================================================================
-- ADDITIONAL USEFUL QUERIES
-- ============================================================================

-- Customer lifetime value
SELECT 
    c.customer_id,
    c.customer_name,
    COUNT(s.transaction_id) AS total_orders,
    SUM(s.total_amount) AS lifetime_value
FROM customers c
JOIN sales_data s ON c.customer_id = s.customer_id
GROUP BY c.customer_id, c.customer_name
ORDER BY lifetime_value DESC
LIMIT 10;

-- Sales by product category
SELECT 
    p.category,
    COUNT(s.transaction_id) AS total_transactions,
    SUM(s.total_amount) AS category_revenue,
    ROUND(100.0 * SUM(s.total_amount) / 
          (SELECT SUM(total_amount) FROM sales_data), 2) AS revenue_percentage
FROM sales_data s
JOIN products p ON s.product_id = p.product_id
GROUP BY p.category
ORDER BY category_revenue DESC;

-- Return rate by product
SELECT 
    p.product_name,
    COUNT(s.transaction_id) AS total_sales,
    COUNT(r.return_id) AS return_count,
    ROUND(100.0 * COUNT(r.return_id) / COUNT(s.transaction_id), 2) AS return_rate_percentage
FROM sales_data s
LEFT JOIN returns r ON s.transaction_id = r.transaction_id
JOIN products p ON s.product_id = p.product_id
GROUP BY p.product_id, p.product_name
HAVING COUNT(s.transaction_id) > 0
ORDER BY return_rate_percentage DESC;

-- Sales performance by sales rep
SELECT 
    sr.sales_rep_name,
    sr.region_id,
    COUNT(s.transaction_id) AS total_transactions,
    SUM(s.total_amount) AS total_sales,
    ROUND(AVG(s.total_amount), 2) AS avg_order_value
FROM sales_data s
JOIN sales_reps sr ON s.sales_rep_id = sr.sales_rep_id
GROUP BY sr.sales_rep_id, sr.sales_rep_name, sr.region_id
ORDER BY total_sales DESC;

-- Daily sales trend
SELECT 
    sale_date,
    COUNT(transaction_id) AS daily_orders,
    SUM(total_amount) AS daily_revenue
FROM sales_data
GROUP BY sale_date
ORDER BY sale_date;

-- Customer segmentation by spending
SELECT 
    customer_id,
    total_spent,
    CASE 
        WHEN total_spent < 200 THEN 'Low'
        WHEN total_spent < 500 THEN 'Medium'
        ELSE 'High'
    END AS spending_segment
FROM (
    SELECT 
        customer_id,
        SUM(total_amount) AS total_spent
    FROM sales_data
    GROUP BY customer_id
) 
ORDER BY total_spent DESC;

