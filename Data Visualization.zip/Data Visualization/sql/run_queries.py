# ============================================================================
# Run SQL Queries using Python
# ============================================================================

import sqlite3
import os

# Get the base directory
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
db_path = os.path.join(base_dir, 'sales_database.db')

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

print("=" * 60)
print("SQL Query Results")
print("=" * 60)

# Query 1: Total sales per region
print("\n1. Total Sales Per Region:")
print("-" * 40)
cursor.execute("""
SELECT 
        r.region_name,
        COUNT(s.transaction_id) AS total_transactions,
        ROUND(SUM(s.total_amount), 2) AS total_sales
    FROM sales_data s
    JOIN regions r ON s.region_id = r.region_id
    GROUP BY r.region_name
    ORDER BY total_sales DESC
""")
for row in cursor.fetchall():
    print(f"  {row[0]}: ${row[2]:,.2f} ({row[1]} orders)")

# Query 2: Top 5 best-selling products
print("\n2. Top 5 Best-Selling Products:")
print("-" * 40)
cursor.execute("""
    SELECT 
        p.product_name,
        p.category,
        SUM(s.quantity) AS total_quantity,
        ROUND(SUM(s.total_amount), 2) AS total_revenue
    FROM sales_data s
    JOIN products p ON s.product_id = p.product_id
    GROUP BY p.product_id, p.product_name, p.category
    ORDER BY total_quantity DESC
    LIMIT 5
""")
for i, row in enumerate(cursor.fetchall(), 1):
    print(f"  {i}. {row[0]} ({row[1]}) - {row[2]} units, ${row[3]:,.2f}")

# Query 3: Monthly revenue
print("\n3. Monthly Revenue:")
print("-" * 40)
cursor.execute("""
    SELECT 
        strftime('%Y-%m', sale_date) AS month,
        COUNT(transaction_id) AS total_orders,
        ROUND(SUM(total_amount), 2) AS monthly_revenue
    FROM sales_data
    GROUP BY strftime('%Y-%m', sale_date)
    ORDER BY month
""")
for row in cursor.fetchall():
    print(f"  {row[0]}: ${row[2]:,.2f} ({row[1]} orders)")

# Query 4: Repeat customers
print("\n4. Repeat Customers:")
print("-" * 40)
cursor.execute("""
    SELECT 
        customer_id,
        COUNT(transaction_id) AS purchase_count,
        ROUND(SUM(total_amount), 2) AS total_spent
    FROM sales_data
    GROUP BY customer_id
    HAVING COUNT(transaction_id) > 1
    ORDER BY purchase_count DESC
    LIMIT 10
""")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} orders, ${row[2]:,.2f}")

# Query 5: Average order value per region
print("\n5. Average Order Value Per Region:")
print("-" * 40)
cursor.execute("""
    SELECT 
        r.region_name,
        ROUND(AVG(s.total_amount), 2) AS avg_order_value,
        COUNT(s.transaction_id) AS total_orders
    FROM sales_data s
    JOIN regions r ON s.region_id = r.region_id
    GROUP BY r.region_name
    ORDER BY avg_order_value DESC
""")
for row in cursor.fetchall():
    print(f"  {row[0]}: ${row[1]:,.2f} avg ({row[2]} orders)")

# Query 6: Peak sales hour
print("\n6. Peak Sales Hour:")
print("-" * 40)
cursor.execute("""
    SELECT 
        CAST(strftime('%H', sale_time) AS INTEGER) AS hour,
        COUNT(transaction_id) AS number_of_orders,
        ROUND(SUM(total_amount), 2) AS hourly_revenue
    FROM sales_data
    GROUP BY hour
    ORDER BY number_of_orders DESC
    LIMIT 5
""")
for row in cursor.fetchall():
    print(f"  {row[0]:02d}:00 - {row[0]:02d}:59: {row[1]} orders, ${row[2]:,.2f}")

# Query 7: Product ranking within category
print("\n7. Product Ranking Within Category:")
print("-" * 40)
cursor.execute("""
    SELECT 
        p.category,
        p.product_name,
        ROUND(SUM(s.total_amount), 2) AS total_revenue,
        RANK() OVER (PARTITION BY p.category ORDER BY SUM(s.total_amount) DESC) AS rank_in_category
    FROM sales_data s
    JOIN products p ON s.product_id = p.product_id
    GROUP BY p.category, p.product_id, p.product_name
    ORDER BY p.category, rank_in_category
""")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} - Rank #{row[3]} (${row[2]:,.2f})")

conn.close()
print("\n" + "=" * 60)
print("All queries executed successfully!")
print("=" * 60)

